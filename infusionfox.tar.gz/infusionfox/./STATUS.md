# Status

A living document. What's in flight, what's deferred, what's known-weird. Maintained by hand — not auto-generated. Update when you finish or defer something.

Last updated: see git log.

## In flight

Nothing currently being actively built. Recent additions:

- **Blood gas interpretation calculator** (`/blood-gas`). Identifies the primary acid-base disturbance from pH, PCO2, and HCO3-; checks compensation against the species- and acuity-specific rule of thumb (DiBartola Table 12-2); computes anion gap when Na and Cl are supplied. Encodes the cat metabolic acidosis caveat (DiBartola Ch. 12 p. 304): the dog compensation rule is not extrapolated to cats, and a danger-class warning surfaces in the result panel. Article at `/learn/blood-gas`. Tests at `tests/calculators/test_blood_gas.py` (26 tests) + entries in `tests/calculators/test_input_validation.py` (7 tests).
- **Nine new practice problems** (P11–P19 in `app/practice.py`) covering primary disturbance identification, acute vs chronic respiratory compensation, mixed disorders, the cat metabolic acidosis caveat, counterbalancing mixed disorders, hypernatremia free-water-deficit math, transfusion volume math, and tube feeding RER math.

## Deferred

### Auth and billing — outsourcing

The codebase has a fairly complete auth + billing schema (users, sessions, magic-link tokens, products, subscriptions, purchases, entitlements, disclaimer acceptances). This is being **removed** in favor of an outsourced provider. When that work happens:

- Delete the auth tables from `app/db/models.py` (keep `disclaimer_acceptances` and `feedback`)
- Delete `app/auth.py` and `app/services/disclaimer.py` (or rewrite the latter against the new provider)
- Delete `app/email.py` (magic-link email sender)
- Remove the auth/registration routes
- Generate an Alembic migration to drop the obsolete tables
- Update README to reflect the new auth model

The clinical content (calculators, hubs, learn modules, articles) is auth-agnostic and will continue to work unchanged.

### Cloudflare Zero Trust for closed beta

Plan to put the app behind Cloudflare Zero Trust Access with email-OTP for beta users, with the homepage and static assets bypassed so the marketing page stays public. Setup is infrastructure-only (no code change). See conversation context for details. Deferred until closer to a real beta.

### Postgres migration

SQLite is fine for current scale and a single Docker container. Postgres becomes worth doing when (a) we go multi-instance behind a load balancer, (b) we need streaming replication / PITR, or (c) we hit write contention. None of those are true now. Migration path: SQLAlchemy + Alembic both support Postgres; the SQLite-specific bits (`render_as_batch=True` in `alembic/env.py`, the `_sqlite_pragmas` event listener in `app/db/session.py`) are localized. Should be a one-week project when the time comes.

### Public homepage / private app split

Idea: make the homepage publicly indexable (SEO, marketing) while gating the rest of the app behind auth. The homepage currently surfaces specific calculator names. Two paths: render the same template with auth-state branching, or build a separate `/about` page and redirect unauthenticated `/` traffic. Deferred.

### Per-user default doses on the anesthesia worksheet

Today, the picker defaults in `anesthesia_sheet.py` are hardcoded and identical for every visitor. Let users save their own preferred starting doses per drug per species.

Depends on auth being in place — the feature only makes sense with a stable user identifier. Browser-side localStorage is not an acceptable substitute (loses on cache clear, doesn't follow across devices, and "my defaults" in a clinical tool needs to actually be persistent).

Sketch when ready to build:

- `user_drug_defaults(user_id, drug_name, species, dose)` table
- A "My defaults" settings page (probably accessible from the worksheet picker header)
- The compute function checks user overrides first, then falls back to app defaults
- Per-drug "reset to app default" button + an "all back to app defaults" escape hatch
- Validation when published ranges change (e.g., new Plumb's edition narrows a range) — handle by clamping silently or warning the user; needs a product decision

Open product questions to settle before building:

- Per-drug vs. per-protocol (e.g., "lap pyometra dog" vs. "dental cat" with different defaults each)?
- Override the dose only, or also which drugs are pre-selected?
- Clinic-wide defaults vs. individual DVM?
- Audit trail of who set what when?

Estimated 1–2 weeks of focused engineering once the design questions are settled.

### Articles section with paid contributors

Strategic direction: follow the model that VetGirl, Clinician's Brief, and VIN use — vet-authored clinical content with bylines, citations, and an editorial process. Worth doing eventually for SEO surface area, peer-trust signal, contributor network effects, and editorial moat.

Decisions made in advance:

- **Paid contributors only.** Unpaid clinical writing produces worse content and burns out contributors. Initial rate range: $200–500 per commissioned article, with longer/CE-accredited pieces priced higher.
- **Commissioned topics first, open submissions later.** Start by reaching out to 2–3 known specialists with a specific scope and deadline. Establish the editorial voice with those pieces before opening to inbound submissions.
- **Flat per-article fee, payment on acceptance** (not on submission) — gives the editor leverage to require revisions.

Open before starting:

- Budget for year one (drives how many pieces can be commissioned)
- Contributor agreement (lawyer review needed): payment terms, copyright assignment vs. license, revision rounds, indemnification, conflict-of-interest disclosure
- 1099 process for US contributors paid over $600/year
- Topic priority list — fill gaps in existing content, target search queries infusionfox should rank for
- Identify first 2–3 commission targets (specialists in different areas — cardiology, criticalist, ER — for breadth)
- Article-section infrastructure: author bylines, article index page, tagging, byline metadata in markdown front-matter

Approximate first-year cost: $5,000–8,000 in contributor fees + editorial time + (small) figure/illustration budget.

Realistic ramp: months 1–2 infrastructure; months 3–4 first 2–3 commissions; months 5–8 expand to 4–6 more; months 9–12 open to inbound pitches. Roughly 12–15 articles published in year one.

## Known caveats

### Anesthesia worksheet

The picker uses `hx-preserve="true"` to keep its DOM intact across HTMX swaps. This means:

- The count badges ("3 of 3") are updated client-side, not server-side. There's a JS handler in `anesthesia_hub.html` that counts checked boxes and updates the badge text.
- Species change is **not** an in-place swap. The species radios are wired with `hx-get="/anesthesia?species=..."` + `hx-target="body"` + `hx-include="this"`, so changing species reloads the entire page at the new species with weight, patient info, picker selections, and result panel all cleared. This is the "blank slate" safety design: there's no previous-species DOM to leak into the new species' picker, so the picker preservation (`hx-preserve`) operates only within a single species — exactly the scope it's meant for.
- Don't add server-rendered content inside the picker without a client-side updater. It will go stale.

See `docs/anesthesia-worksheet.md` for the full architecture.

### Dexmedetomidine default-setting

Dex is the only drug whose display unit (µg/kg) differs from its storage unit (mg/kg). The `_drug()` helper in `anesthesia_sheet.py` handles the conversion: callers pass `default_dose`, `low`, and `high` in the display unit (µg/kg for dex, mg/kg for everything else), and the helper divides by `dose_display_multiplier` internally before storing. One code path, one unit per drug at the call site.

Current dex defaults: dog 5 µg/kg, cat 10 µg/kg.

(Historical note: earlier versions used a post-construction `DrugLine(...)` rebuild because the call-site values had to be written in storage units — 0.000005 mg/kg for 5 µg/kg, which was easy to miscount the zeros on. That rebuild is gone. If you're working from a branch that predates the unit-conversion refactor and still has the rebuild block, the calculator works correctly but the `default_dose=` argument on the dex `_drug()` call is silently overwritten there.)

### Cat dobutamine ladder cautions

Cats are sensitive to dobutamine (seizures, arrhythmias above 5 µg/kg/min). The titration ladder flags steps above 5 µg/kg/min with `is_caution=True`, which renders a visual caution marker on the UI. The published range (2–20 µg/kg/min) is preserved because rare clinical scenarios call for it. Don't remove these flags.

### Worked-example mechanism is global, not per-page

The KaTeX rendering for worked-example formulas is handled by a single global handler in `base.html`. Result partials emit `<template id="worked-example-source...">` blocks; the handler finds matching `#worked-example...` targets on the page and renders LaTeX into them.

**Result:** don't add inline `<script>` blocks inside result partials to render math. They don't reliably execute after HTMX swaps. Use the template mechanism instead.

### KaTeX requires markdown pre-processing

Markdown articles in `content/drugs/*.md` use `$$...$$` blocks for math. The markdown renderer would otherwise interpret underscores inside math as italic. The renderers in `app/routers/learn.py` and `app/routers/content.py` (`_render_markdown`) pre-process the markdown to protect math blocks from underscore-as-italic interpretation. They also strip YAML front-matter.

If you add a new markdown-rendering route, copy the pre-processing.

## What's clean / non-surprising

For the avoidance of doubt, these things work the way you'd expect:

- **Adding a new CRI calculator**: one entry in `app/calculators/drugs.py`, one markdown article in `content/drugs/`, restart. Nav, catalog, page, and `/learn/<slug>` all auto-generate.
- **Adding a new bespoke calculator**: follow the recipe in `CONTRIBUTING.md`. Auto-discovery in `app/routers/__init__.py` picks it up — no `main.py` edit.
- **Database migrations**: standard Alembic. `alembic revision --autogenerate -m "..."` then `alembic upgrade head`. CI checks for schema drift.
- **Tests**: `pytest` runs the suite in ~10 seconds. Required for every change per `CONTRIBUTING.md`.
- **Production deploy**: GitHub Actions → GHCR → Watchtower → Cloudflare Tunnel. See `DEPLOYMENT.md`.
