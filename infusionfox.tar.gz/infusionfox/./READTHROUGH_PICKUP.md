# InfusionFox complete read-through — DONE (session 12)

## Final status snapshot
- All `app/` source done (28 calculators + 47 routers + foundation + learning + practice).
- All `app/templates/` complete (112/112) ✅
- All 33 markdown articles in `content/drugs/` ✅
- All 50 test files in `tests/` ✅
- All `app/static/css/app.css` (3453 lines) + fonts.css ✅
- All alembic (env.py + baseline migration 4ae1376d9f7c + script.py.mako + alembic.ini) ✅
- All scripts (entrypoint.sh + check_templates.py + verify_against_spreadsheet.py + build_review_packet.py) ✅
- All configs (Dockerfile + docker-compose.yml + docker-compose.prod.yml + .github/workflows/{ci,build}.yml + pyproject.toml + requirements.txt + requirements-dev.txt + .env.example + site.webmanifest) ✅

Binary assets (SVG logos, woff2 fonts, PNG favicons, mp4 hero animation, SQLite DB) intentionally skipped — Tim's read-through directive was about source.

## Standing rules (DO NOT DRIFT)
1. GitHub is NOT canonical. Never recommend deleting his folder or extracting fresh.
2. Em-dashes nuanced. OK in code comments / short choice strings / titles with parenthetical setoff / conversational chat replies. NOT OK in long-form prose. Style guide §10: >1 per page = rewrite.
3. Read docs/style-guide.md, SOURCES.md, CONTRIBUTING.md before any code work.
4. Bundle name ALWAYS cageside.tar.gz at /mnt/user-data/outputs/.
5. Never recommend Google services without explicit permission.
6. Decomposing anesthesia_sheet.py is off-limits.
7. Disclaimer acceptance returns tied to user accounts at registration with version-bump re-acceptance — leave room in design but don't reimplement now.
8. Working dir is /home/claude/work/infusionfox.

## Tim's tone calibration
Silent, methodical reading across sessions. NO commentary between files. JUST view tool calls. This phase is now complete.

## Key facts cumulative (session 12 closeout)

### app.css final sections
- Lines 2400-2900: practice-check (input + button), .practice-check--mc (fieldset reset for MC blocks), .practice-card__refs/__ref/__ref-label/__ref-name, .drawer-toggle (hamburger 3-bar), .site-header__brand-cluster, .drawer-backdrop rgba(15,22,35,0.45), .drawer 22rem max-width:calc(100vw-3rem) translateX(-100%) → 0 on .drawer--open, .drawer__inner/__header/__brand, .visually-hidden ARIA pattern, .drawer__close/__content, .drawer-group__title/__list/__short, hero__left flex column, hero__valueprop max-width 60ch, mobile hero CTA/valueprop order swap on <900px, .hero__ctas margin-top:auto, .hero__ctas full-width below 880px, .hero__right with .hero__shot bordered tile + .hero__shot--animation aspect 734/858 max-width 420px (portrait phone-shaped), object-fit:cover on .hero__shot-video
- Lines 2900-3454: tube-feeding-print classes (print-only writein for hand-dating, print-header field grid), tube-feeding-highlights__grid 3-col (Tube selection/When to start/When to discontinue, collapses to 1col below 760px), learn-module-list/card/__meta (CE in accent color, components pills), .learn-module-meta strip, .learn-module-video aspect 16/9 with absolutely-positioned iframe, .learn-module-calculators auto-fit minmax 280px, .learn-module-practice with __topic flex-shrink:0 right-aligned, .learn-module-quiz with counter-increment quiz-q::before counter() rendering "N. " in accent, __verdict.is-correct #2f7d3a vs .is-incorrect #a04040, .cri-mode-toggle grid-template-areas with :has(input:checked) state, .result__mode-banner with accent left-border, .bag-prep-card__steps padded ordered list, .titration-ladder__note + .titration-callout (titration callout with --accent-warning #c47c00), @media print: hide drawer/backdrop/toggle, bg-form :has() scoping for 4-way species×sample range hint matching, .bg-range__qual italic qualifier text

### alembic
- `env.py`: imports app.db.models.Base + app.db.session.DB_URL; overrides alembic.ini sqlalchemy.url with DB_URL at runtime; uses render_as_batch for SQLite; standard offline+online migration code
- `versions/4ae1376d9f7c_baseline_schema_feedback_only.py`: 2026-05-26 baseline; creates only `feedback` table (id INT PK, page_url 500, kind enum BUG/SUGGESTION/MISSING_DRUG/DOSE_CONCERN/OTHER, message TEXT, contact_email 320, status enum NEW/SEEN/RESOLVED/IGNORED, admin_note TEXT, user_agent 500, ip_address 64, created_at DT+tz, resolved_at DT+tz); index on created_at via batch_alter_table; down_revision=None so this is the single root
- `script.py.mako`: standard alembic template
- `alembic.ini`: script_location %(here)s/alembic, prepend_sys_path=., path_separator=os, sqlalchemy.url placeholder (overridden by env.py), generic single-DB config

### scripts/
- `entrypoint.sh` (~218 lines): 4-state DB handler — (1) empty DB → alembic upgrade, (2) alembic-managed at known revision → upgrade, (3) legacy schema present without alembic_version → stamp head then upgrade, (4) DB pinned to UNKNOWN revision → destructive recovery (drops LEGACY_TABLES: audit_log/ce_records/disclaimer_acceptances/entitlements/purchases/subscriptions/products/magic_link_tokens/sessions/users + DROP TABLE alembic_version, then stamp head; preserves feedback). Defensive sweep #1 (BASELINE_REV=4ae1376d9f7c) sweeps stale migration files from VERSIONS_DIR plus __pycache__. Defensive sweep #2 deletes ORPHANED_FILES (app/auth.py, app/email.py, app/routers/{auth,account_admin}.py, app/services/disclaimer.py, app/templates/{account,pricing}.html) + ORPHANED_DIRS (app/templates/{auth,admin}/) plus find -name __pycache__ -exec rm -rf. Final exec: uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers --forwarded-allow-ips='*'.
- `check_templates.py`: Jinja2 Environment(FileSystemLoader(app/templates)); rglob *.html; calls env.parse on each; collects TemplateSyntaxError; prints "✓ N templates parse cleanly" or sys.exit(1) with line-number errors
- `verify_against_spreadsheet.py`: CRI_Calculator.xlsx defaults — NE 90 lb 0.1 ug/kg/min 80, Epi 50 lb 0.1 80, Dob 90 lb 5 1000, Fent 75 lb 10 (ug/kg/hr) 50; asserts compute() matches manual formula via lb-to-kg division 2.20462; also cat dobutamine 5 µg/kg/min produces "CAUTION" warning; dilution checks (12500→1000 in 50 mL = 4 mL; 1000→80 in 50 mL = 4 mL). NOTE: path hardcoded `sys.path.insert(0, "/home/claude/infusionfox")` which is wrong - should be /home/claude/work/infusionfox. Marked continue-on-error in CI.
- `build_review_packet.py` (1497 lines): Generates per-calculator PDF review packet via reportlab. 28 page_* functions covering every calculator. Priority order — P1 high-alert hyperK bridge (ca_gluconate, insulin_dextrose), P2 high-alert pressors/emergency (cpr, norepi, epi, dobutamine, dopamine_prep, dopamine-cri, insulin_cri_dka, insulin_im_dka), P3 foundational fluid+electrolyte (fluid_therapy, hypernatremia, fentanyl), P4 published-table electrolytes (hypokalemia, hypomagnesemia, hypophosphatemia), P5 dog-only (lidocaine), P6 analgesia/sedation (ketamine, propofol, methadone, hydromorphone, alfaxalone, mlk, kitty_magic, cornell_onco_kl), P7 diagnostic/nutrition (iris_staging, lddst, cushings_score, energy). Each page: question + inputs + encoded ranges (tables via _wrap_table) + warnings + cited source + reviewer markup box (☐ Matches reference, notes, initials/date). _engine_drug_page helper handles all SINGLE_DRUG_CRI drugs. Output: data/peer_review_packet.pdf.

### Configs
- `Dockerfile`: python:3.12-slim base, apt install curl, pip install requirements.txt, non-root user `infusionfox`, /data writable, COPY --chown, HEALTHCHECK /health every 30s, CMD scripts/entrypoint.sh
- `docker-compose.yml` (dev): build:., image infusionfox:dev, env_file .env, port ${INFUSIONFOX_PORT:-8765}:8000, volumes infusionfox_data:/data + ./content:/app/content:ro for hot edits
- `docker-compose.prod.yml`: image ghcr.io/wolfcolatom/infusionfox:latest, port 8000:8000, labels include com.centurylinklabs.watchtower.enable=true for auto-update; content bind-mount commented out
- `.github/workflows/ci.yml`: python 3.12 + cache pip, installs requirements + requirements-dev; ruff check + ruff format --check; mypy app/ (continue-on-error); python scripts/check_templates.py; alembic upgrade head + alembic check (export INFUSIONFOX_DB_URL=sqlite:///$RUNNER_TEMP/ci-alembic.db); pytest --tb=short; python scripts/verify_against_spreadsheet.py (continue-on-error: legacy script)
- `.github/workflows/build.yml`: GHCR push on push to main + workflow_dispatch; docker/setup-buildx-action@v3 + login-action@v3 + metadata-action@v5 + build-push-action@v5; two tags — `latest` (Watchtower-followed) + type=sha,format=short (immutable rollback); gha cache
- `pyproject.toml`: python>=3.12, pytest with -v --strict-markers --strict-config -ra, markers slow+integration; ruff line-length=110 target-version=py312 extend-exclude alembic/versions+data; ruff.select E F I B SIM C4 UP RUF; ignore E501+B008+SIM108+UP042; per-file-ignores app/*+tests/* keep RUF001/002/003 (×, µ, ≤, ≥, →, –) deliberately; mypy disallow_untyped_defs but overrides for app.calculators.{engine,drugs,utilities} (older code) and tests/* (relaxed)
- `requirements.txt`: fastapi 0.115.0, uvicorn[standard] 0.32.0, jinja2 3.1.4, python-multipart 0.0.12, markdown 3.7, sqlalchemy 2.0.36, alembic 1.14.0, httpx 0.27.2, sentry-sdk[fastapi] 2.18.0
- `requirements-dev.txt`: pytest 8.3.4, pytest-cov 6.0.0, ruff 0.7.4, mypy 1.13.0, pre-commit 4.0.1, types-Markdown 3.7
- `.env.example`: INFUSIONFOX_PORT 8765, INFUSIONFOX_ADMIN_TOKEN (remove after first admin promote), INFUSIONFOX_SHOW_AUTH_PRICING_UI feature flag for /pricing+/auth+/account links (default 0 for private beta), CLOUDFLARE_TUNNEL_TOKEN (prod only), commented-out RESEND_API_KEY/INFUSIONFOX_EMAIL_FROM, STRIPE_* keys, MUX_* webinar keys
- `app/static/css/fonts.css`: IBM Plex Serif (400/500/600/700/italic 400), Sans (400/500/600/700), Mono (400/500/600/700) — self-hosted woff2 in /static/fonts/, font-display:swap
- `app/static/site.webmanifest`: name "InfusionFox", icons 192/512, theme_color #1C3A57, background_color #F4F1EA, display standalone

## Mid-readthrough fixes carried forward
1. Blood gas + LDDST placeholder text bug fixed with `placeholder_message=` param + regression tests
2. Article "Open calculator" link broken for 11 bespoke calcs — `_resolve_calc_url(article_slug)` in app/routers/content.py with `_CALC_URL_OVERRIDES` (energy-requirements → /energy)
3. Blood gas reference range hints (species/sample-aware via CSS `:has()` with `bg-form` scope class)
4. Practice MC radios weren't grouped — fixed in app/templates/practice/_problem_card.html with `{% set check_idx = loop.index0 %}`
5. GABA_A → GABA-A across 5 surfaces
6. Ketamine override removed from `_CALC_URL_OVERRIDES`; coordinated removal pending of app/routers/ketamine.py, app/calculators/ketamine.py, app/templates/ketamine.html, content/drugs/ketamine.md, tests/calculators/test_ketamine.py, KETAMINE_CATALOG_ENTRY registration

**Status after prior fixes: 1008 tests pass, touched files ruff clean, 112 templates parse.** Pre-existing ruff issue in tests/test_alembic_sync.py:12 dated May 9 predates these sessions, untouched.

## NEXT
Read-through is complete. Ready for Tim's next directive.

## Sweep-up additions (after first "Continue")
- `.dockerignore`: drops __pycache__/, *.pyc, .venv/, .env, .git/, .gitignore, .github/, .vscode/, .idea/, *.swp, data/, scripts/ (with `!scripts/entrypoint.sh` exception so the entrypoint IS in the image), tests/, .pytest_cache/, .mypy_cache/, .ruff_cache/, node_modules/. Key insight: tests not shipped to prod image; entrypoint.sh is the only script that makes it.
- `.gitignore`: standard Python (__pycache__, *.pyc, .pytest_cache, .mypy_cache, .ruff_cache, .coverage, .venv); environments (.env, .env.local); data/ and any *.db / *.db-journal / *.db-wal / *.db-shm; IDE (.vscode/, .idea/, *.swp); OS (.DS_Store, Thumbs.db); logs; docker-compose.override.yml; dist/ build/
- `.pre-commit-config.yaml`: ruff v0.7.4 (--fix + format), pre-commit-hooks v5.0.0 (trailing-whitespace + end-of-file-fixer + check-yaml + check-toml + check-added-large-files --maxkb=1024 + check-merge-conflict), and local hook `jinja-parse-check` that runs `python scripts/check_templates.py` on any *.html change with pass_filenames: false
- SVG logos (all 8 in app/static/brand/logos/ + favicon): all use the same teardrop path `M 32 6 C 32 6 50 28 50 40 A 18 18 0 1 1 14 40 C 14 28 32 6 32 6 Z` on a 64×64 viewBox. **mark.svg** is the canonical deep-navy (#1C3A57) drop with a radial gradient (white 55% at upper-left to black 32% at lower-right) — the 3D drop look. **mark-black.svg** plain black silhouette. **mark-white.svg** warm-paper (#F4F1EA) drop with linear shadow + two radial highlights (upper-left + lower-right). **mark-tile.svg** = navy tile bg with paper drop scaled 0.75 (used as the favicon-style square). **wordmark.svg** = 891.4×201.6 viewBox, IBM Plex Serif 700 size 200 letter-spacing -3.60 with the drop scaled and translated next to it at (863.62, 119.38) scale 0.5556 (navy fill). **wordmark-text.svg** is just the text without the drop, 910px viewBox extension. **wordmark-black/-white.svg** color variants. **favicon.svg** = same as mark-tile but with a square (no rounded rx). Hero drop in home.html: `<svg class="hero__drop" viewBox="0 0 64 64" aria-hidden="true"><path d="M 32 6 C 32 6 50 28 50 40 A 18 18 0 1 1 14 40 C 14 28 32 6 32 6 Z"/></svg>` inlined inside the `<h1>` after `<em>infusionfox</em>` to serve as the period; followed by `<span class="visually-hidden">.</span>` for screen readers.

Read-through is fully complete. Source-and-config inventory is exhausted.

## Verbatim user-message sources for the standing rules
(Read across all 20 prior session transcripts in `/mnt/transcripts/` and `/tmp/conv/`, session 12.)

- **GitHub is NOT canonical** → "Also GitHub is not the source of truth" (session 14, deep-read-6, U2).
- **Em-dashes nuanced, not blanket banned** → "Read the other conversations thoroughly. We're going down a slippery slope again with the em-dashes. Let's use them where appropriate, but not in long prose. Again. I have to repeat myself" (session 7, deep-read U1). Also: "We've been over this at least 10 times" (session 5, recurring U18).
- **Bundle name `cageside.tar.gz` is fixed** → "Dont change the fucking name" (session 3, blood-gas-feature U30) — said after the bundle-overlay fiasco.
- **Anesthesia worksheet decomposition off-limits** → "Decomposing the anesthesia worksheet is out of the question. It's made to be functional for clinical practice. If the design needs to be improved we can discuss that, but there is no way its being hacked apart." (session 1, U4).
- **Species-toggle blank-slate** → "Reset everything if you change species. Blank slate. Safest." (session 2, auth-removal-and-sentry U4).
- **Patient bar order** → "Make the species toggle more prominent. Entered first above everything else. Weight should be the first field underneath it. Should go weight, name, age" (session 2 U5).
- **Disclaimer at registration, not per-event** → "I want to outsource auth, but I will need to record disclaimer acceptance" (session 4 U16) and "No, I want them to do it once when they register for the site" (session 4 U17).
- **Ketamine standalone calculator NOT wanted** → "There is no standalone ketamine calculator. At least not currently. i don't want one either." (session 13, deep-read-5 U2). The coordinated removal listed in the pickup is Tim's explicit choice, not an inference.
- **Defensive entrypoint sweeps** → The orphaned-files sweep and migration-file sweep in `scripts/entrypoint.sh` are a direct response to session 3's bundle-overlay incident, where Tim's tar -xzf on top of an existing folder left zombie auth files behind and his own backup *also* showed the broken state (DB+orphaned-files, not bundle). Future rule: a "broken" backup does not by itself mean the bundle is at fault — check entrypoint defensive sweeps first.
- **Dex post-construction rebuild** → exists because the bug ("0.000005 mg is not 5 ug", session 1 U7) had to be fixed without losing the custom starting doses ("sure, but we went through and set custom starting doses and I want those to stay", session 1 U8). The rebuild assigns dose at the right unit AFTER the natural default would have applied.

## Tim's wishlist filter (post-mdcalc.com discussion, session 4 U30)
- iris staging — done
- corrected Ca — "not accurate", do not adopt as-is
- free water deficit — done
- toxicology — decided against (poison control owns)
- APPLE-fast — built but intentionally hidden (specialist-leaning)
- pain scoring — deferred, not ready
- general direction: "i'm more interested in UX"

## Mid-readthrough fixes — verbatim trigger asks
- placeholder text bug → "Awaiting input / Enter a patient weight to see the result. This doesn't make any sense on the acid/base calculator" (session 12, deep-read-4 U3). Follow-up "any other calcs affected by this?" (U4) extended the fix to LDDST.
- blood gas reference range hints → "Can you also add reference ranges on the blood gas calculator page for each input (species dependent)?" (session 13, deep-read-5 U1).
- broken Open-calculator link → "the open calculator link from the clinical background page in acid base is broken" (session 12 U5).
- GABA_A → GABA-A → "Yeah, either make the actual subscript or use a dash" (session 13 U3).
- MC radio grouping → "I noticed that the practice questions dont allow you to select a different answer if you get it wrong" (session 13 U2).

## Tone calibration — explicit feedback
- "I don't understand why this is new information. You're wasting my money sucking away my credits." (session 6, U3)
- "Do it correctly. My last conversations Claude was better than you." (session 7, U5)
- "READ. EVERY. LINE. I'm talking about code AND prior conversations so you are FULLY caught up." (session 16, U1)
- "Can you confidently tell me that you now understand this project to the level of a software engineer who built it?" (session 8, U2) — implicit standard.
