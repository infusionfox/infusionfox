# CLAUDE.md

Orientation for Claude sessions working on infusionfox.com. Written by a session-12 Claude (Sonnet 4.7) after reading every source file, every doc, every test, and all 20 prior conversation transcripts end-to-end. It exists because that read-through cycle had repeated across at least 8 prior sessions before this one, costing real money and real frustration. Read this carefully at session start; you should not have to repeat the cycle.

## Who Tim is

Dr. Timothy Curran, DVM. Practicing veterinarian, sole author of this app. He wears scrubs at the clinic. He runs the production stack on a Synology NAS fronted by a Cloudflare Tunnel for ingress, and deploys manually via git. He has a sophisticated home lab and is privacy-conscious by default. He uses the mobile Claude app a lot and values brevity, directness, and proof.

He gets frustrated when Claude oversells understanding, drifts from established style, or suggests things he has already considered and rejected. He has compared past Claudes ("My last conversations Claude was better than you" was a real quote from session 7). The bar for "I understand this project" is high.

## Read these before writing any code

In order, at session start, and especially before any edit:

1. `docs/style-guide.md` — em-dash rule, copy style, formatting expectations
2. `docs/architecture.md` — request flow, the two calculator patterns
3. `docs/anesthesia-worksheet.md` — the most complex module and rules about what NOT to touch
4. `docs/htmx-patterns.md` — swap-target conventions, hx-preserve, worked-example mechanism
5. `CONTRIBUTING.md` — testing discipline and citation rules
6. `SOURCES.md` — canonical reference list and per-calculator attribution
7. `STATUS.md` — what is in flight, what is deferred
8. `READTHROUGH_PICKUP.md` if present — session-state from a prior Claude

Then targeted reads based on the task. Skim, do not memorize. The map matters more than the contents.

## Non-negotiable standing rules

These are not preferences. Each comes from a specific prior-session conversation with Tim. Provenance is preserved so you can verify.

1. **Em-dashes are nuanced, not banned.** They are appropriate in code comments, short choice strings, button labels, headings with a parenthetical setoff, and conversational chat replies. They are NOT appropriate in long-form prose: articles, page intros, warnings, clinical backgrounds. The rule of thumb from `docs/style-guide.md` §10 is that more than one em-dash per page of prose means rewrite. Use parentheses, commas, colons, or separate sentences instead.
   Source (session 7): "Let's use them where appropriate, but not in long prose. Again. I have to repeat myself." Session 5: "We've been over this at least 10 times."

2. **The bundle name is fixed.** Output bundles ALWAYS go to `/mnt/user-data/outputs/cageside.tar.gz`. Renaming the bundle was the trigger for a session-3 incident where Tim thought the project had been destroyed.
   Source (session 3): "Dont change the fucking name."

3. **Anesthesia worksheet decomposition is off-limits.** Improvements inside its current shape are welcome; structural refactoring is not. The module is ~1257 lines and shaped the way it is for clinical reasons.
   Source (session 1): "Decomposing the anesthesia worksheet is out of the question. It's made to be functional for clinical practice. If the design needs to be improved we can discuss that, but there is no way its being hacked apart."

4. **Never recommend Google services without explicit permission.** This covers Fonts, Analytics, reCAPTCHA, Cloud, Firebase, Gmail integrations, Maps, YouTube embeds, and so on. If a Google service genuinely is the right answer, surface it as an option and ask. Always present privacy-respecting alternatives.

5. **Disclaimer acceptance is per-user-at-registration, version-bumped on update.** Not per-event. Auth has been removed in the recent refactor; the disclaimer model is reserved for when auth returns through an outsourced provider. Do not reimplement now, but leave structural room.
   Source (session 4): "I want to outsource auth, but I will need to record disclaimer acceptance." "No, I want them to do it once when they register for the site."

6. **The audience is the clinician.** Do not introduce defensive Claude-style hedging into clinical copy. No "consult your veterinarian" boilerplate. The disclaimer at `/disclaimer` covers that ground. Speak the language the clinician uses.

7. **The working directory is `/home/claude/work/infusionfox`.** Tim's bundle uploads land in `/mnt/user-data/uploads`; extract into the working dir, never overlay onto an existing tree (that is the session-3 incident).

8. **Calculators NEVER show output before the clinician enters values. Hard safety rule.** This applies on initial GET, on partially-filled forms, and on any path where required inputs are absent or unparseable. A pre-populated "default" score, dose, or interpretation that looks like a real result is a patient-safety hazard — it can be misread as the patient's actual values. The canonical pattern from `app/routers/blood_gas.py` and `app/templates/blood_gas.html` is the reference implementation:
   - GET handler passes `result=None` and empty-string field values to the template.
   - Page template gates with `{% if result %}{% include "partials/<calc>_result.html" %}{% else %}{% include "partials/_invalid_input_placeholder.html" %}{% endif %}`. Pass a `placeholder_message` naming the required inputs.
   - POST handler validates that every required input is present and parseable; if any is missing or invalid, return the placeholder partial (with the same `id="result-panel"`) so the existing HTMX target is replaced cleanly.
   - Form parameter defaults are `""`, not "0" or any other numeric sentinel that could be silently substituted. Use `parse_positive_float()` from `_form_parsing.py` and treat `None` as "not entered" before constructing the inputs dataclass.
   - For radio/select inputs where a value of 0 is semantically valid (e.g. mentation scores 0–4), do NOT pre-check any option. Treat "no radio selected" as not entered and require explicit user choice.
   - The form's `hx-trigger` MUST NOT include `load` — that fires on page load before the user has typed anything, producing exactly the misleading "first-render score" the rule forbids. Use `"input changed delay:Nms, change"` only.
   - Tests must verify: GET returns placeholder language and NOT a score/dose; partial inputs return placeholder; bad inputs return placeholder, not a result with substituted defaults.

   Source (session 16): "No calculators should ever have that based upon a hard rule for safety… for consistency it should not show any output until values are entered like the other calculators. Please ensure this is updated and clearly documented for all future calculators."

## Architecture in 60 seconds

FastAPI 0.115 + Jinja2 + HTMX 2.0.2 + SQLite + Alembic. No JS framework, no build pipeline. Routers in `app/routers/` are auto-discovered at startup by `app/routers/__init__.py` (any module exposing a top-level `router = APIRouter()` is registered). KaTeX is loaded via CDN and renders worked-example LaTeX server-emitted as inline `<template>` blocks. Production deploy is manual via git, with GitHub Actions building images to GHCR for record-keeping and rollback availability. Ingress through a Cloudflare Tunnel.

Calculators come in two patterns.

**Engine-driven.** One `CalculatorConfig` row in `app/calculators/drugs.py`. The engine in `app/calculators/engine.py` handles the math (weight × dose × 60 / concentration, with unit-aware switching for µg/kg/min vs µg/kg/hr drugs). Currently: norepinephrine, epinephrine, dobutamine, fentanyl, dopamine-cri. Adding one is a single dict entry plus a markdown article.

**Bespoke.** One module in `app/calculators/<name>.py` exposing `compute_<name>(inputs)` returning a result dataclass with `valid: bool`, `warnings`, `notes`, and `sources: tuple[Source, ...]`. Use when math doesn't fit the engine: sliding scales, multi-step prep, scoring tools, multi-output protocols. 23 bespoke calculators currently.

The request lifecycle for a typical calculator: GET `/<slug>` renders the page shell with an empty result panel; the form posts via HTMX (`hx-post`, `hx-target="#result-panel"`, `hx-swap="outerHTML"`, `hx-trigger="input changed delay:250ms, change, load"`); the handler computes and returns `partials/<slug>_result.html`; HTMX swaps it in. Recomputation is automatic on every input change.

The anesthesia worksheet (`/anesthesia`) is the exception to most conventions. It uses a larger swap target (`#anesthesia-sheet-wrapper`), preserves the picker DOM via `hx-preserve`, and treats species-toggle as a full-page reload (blank slate, safest). Read `docs/anesthesia-worksheet.md` before touching it.

## Project UI standards

These are the established patterns. Follow them when the conditions are met; don't roll your own variant.

**Multi-concentration prep-card with disclosure.** Any calculator where a drug has multiple commonly-stocked concentrations uses the same UX. Big prep-card showing the active concentration in large font, "Use a different concentration" disclosure for alternatives. The default is whatever your hospital is most likely to stock. Currently in use on all 4 multi-preset engine drugs (epi, dobutamine, dopamine-cri, fentanyl), the original norepinephrine page, and the bespoke hydromorphone CRI calculator. The pattern is generalized in `app/templates/calculator.html`; the router computes `default_preset` and `alt_presets` in `_render_single_drug`. Undiluted-vial warning presets (e.g. dobutamine 12500 µg/mL) are flagged `pump_safe=False` on `ConcentrationPreset` and filtered out of the disclosure. See `docs/htmx-patterns.md` for the full implementation. Don't add a flat `<select>` dropdown for concentrations on a new calculator — use the prep-card pattern.

**Worksheet per-drug concentration selectors.** A compact in-row variant of the prep-card pattern, used in the anesthesia worksheet picker. Per-drug `<select name="stock_<drug>">` below each drug's dose input. List of drugs that get a selector is `STOCK_OPTIONS` in `app/calculators/anesthesia_sheet.py`. Chosen value rides through `calculate()` via a `contextvars.ContextVar` so `_drug()` call sites pick it up without a signature change. Atropine and naloxone get their own "Emergency drug concentrations" picker section because they don't appear in the opioid/sedative/induction sections. See `docs/anesthesia-worksheet.md`.

**Required form inputs must have non-empty defaults.** htmx 2.x silently blocks form submission when a required input is empty. Calculator forms must pre-fill every `required` input that isn't the patient weight (which the user types) with a sensible default. `tests/test_form_defaults.py` enforces this across every calculator page; adding a calculator with an unfilled required input fails CI.

## What lives where

```
app/
  main.py                     FastAPI entry; mounts static, registers routers
  nav.py                      single source of truth for site navigation (720 lines)
  practice.py                 practice problem catalog (1619 lines)
  learning.py                 learn-module catalog (353 lines)
  observability.py            Sentry hooks
  logging_config.py
  calculators/
    engine.py                 generic CRI engine (805 lines)
    drugs.py                  CalculatorConfig per engine drug (902 lines)
    utilities.py              weight, dose, percent, dilution converters
    anesthesia_sheet.py       the big one, off-limits to decomposition (1257 lines)
    <name>.py                 bespoke calculators (28 total)
  routers/__init__.py         auto-discovery
  routers/<name>.py           47 routers (one per calculator and hub)
  templates/base.html         site chrome + KaTeX + worked-example handler
  templates/<name>.html       calculator pages (31)
  templates/partials/         HTMX swap targets and shared fragments (41)
  templates/<hub>.html        reference hubs (7)
  static/css/app.css          single stylesheet (3453 lines; rationale comments inline)
  static/css/fonts.css        self-hosted IBM Plex
  db/models.py                SQLAlchemy models (feedback table only post-auth-removal)
content/drugs/<slug>.md       33 clinical articles
docs/                         style-guide, architecture, anesthesia-worksheet, htmx-patterns
scripts/
  entrypoint.sh               handles 4 DB states + defensive file sweeps
  check_templates.py          jinja parse check (runs in CI)
  verify_against_spreadsheet.py
  build_review_packet.py      generates per-calculator PDF for peer review
alembic/                      env.py + baseline migration (feedback table only)
tests/                        50 test files, 1008+ tests, runs in ~10 seconds
```

## The calculator catalog

28 calculators across these categories:
- Vasopressors and inotropes: norepinephrine, epinephrine, dobutamine, dopamine-cri (engine), dopamine prep (Plumb's 6×kg method)
- Analgesia: fentanyl (engine), methadone, hydromorphone CRI, lidocaine (dog-only), MLK (dog-only), Cornell oncology KL, ketamine (REMOVAL PENDING, see below)
- Anesthesia and sedation: propofol, alfaxalone, kitty magic (cat-only DKT lookup)
- Electrolytes and fluids: hypokalemia, hypomagnesemia, hypophosphatemia, hypernatremia, calcium gluconate (hyperK bridge), insulin + dextrose (hyperK), fluid therapy
- Endocrine and metabolic: insulin CRI · DKA, insulin IM · DKA, LDDST, Cushing's pretest score, Addison's pretest score, hypothyroid pretest score, IRIS CKD staging
- Critical care: blood gas interpretation, CPR (RECOVER 2024 chart)
- Nutrition: energy requirements (RER/MER), tube feeding schedule
- Transfusion: blood product volume calculator
- Tools: weight, fluid rate, drop factor, dilution helpers

Plus 7 reference hubs (CPR, anaphylaxis, hypoglycemia, DKA, hyperkalemia emergency, status epilepticus dog/cat, heatstroke, shock) and the anesthesia worksheet.

**Ketamine calculator removal is pending and explicit.** Tim said (session 13): "There is no standalone ketamine calculator. At least not currently. i don't want one either." Removal is coordinated across `app/routers/ketamine.py`, `app/calculators/ketamine.py`, `app/templates/ketamine.html`, `content/drugs/ketamine.md`, `tests/calculators/test_ketamine.py`, and the catalog entry in `app/calculators/drugs.py`. Do the removal as one bundle, not piecemeal. The `_CALC_URL_OVERRIDES` map in `app/routers/content.py` has had the ketamine override already removed.

## How style works

Read `docs/style-guide.md` for the full rules. Highlights worth pinning:

The em-dash rule is rule #2 above. The CSS in `app/static/css/app.css` has rationale comments inline; the titration table headers deliberately do NOT use `text-transform: uppercase` because CSS uppercasing turns µ into M in many sans-serif fonts, which would silently change a 1000-fold-different unit on a vasopressor table. Read the rationale before changing a CSS rule.

Catalog blurbs are short, declarative, and scannable. They are not marketing copy. Warning text uses specific verbs and noun phrases, not vague exhortations. Unicode operators are deliberate (×, µ, ≤, ≥, →, –, en/em-dashes in appropriate contexts); the `pyproject.toml` ruff config explicitly allows them.

Clinical copy uses the language the clinician uses. Never substitute lay terms for medical ones in the result panel.

## How sources work

Every dose range, threshold, and scoring weight has a citation. `CONTRIBUTING.md` covers this in full. Conventions:

- Result dataclasses expose `sources: tuple[Source, ...]` rendered via `partials/_source_cite.html`.
- `SOURCES.md` is the canonical reference list and the per-calculator attribution table.
- Don't reproduce verbatim source text in user-facing strings. Cite and paraphrase.
- Primary references in active use: Plumb's, DiBartola Ch. 3/5/6/9/12, Silverstein & Hopper 3rd ed (Cooper Ch. 122, Hoehne Ch. 73, Ch. 134), peer-reviewed literature, IRIS guidelines (2023 modification), RECOVER 2024 (Fletcher), ACVIM consensus statements (Behrend 2013, Bennaim review).

## Tests

`pytest` runs the full suite in roughly 10 seconds. 1008+ tests at last count. Every calculator has its own file under `tests/calculators/`. Foundation tests live at the top level. Run all tests after any meaningful change.

The CI workflow at `.github/workflows/ci.yml` runs ruff check + format check, mypy (informational), the template parse check via `scripts/check_templates.py`, an alembic schema drift check (creates a temp DB, upgrades, runs `alembic check`), the full pytest suite, and the spreadsheet verification script (informational; may need updates because of a stale `sys.path.insert(0, "/home/claude/infusionfox")` line).

Coverage targets in tests are deliberate: the engine's unit-conversion math has dedicated tests for both µg/kg/min and µg/kg/hr drugs because a hardcoded × 60 anywhere in a µg/kg/hr template would silently overdose by 60×. The cri-mode-toggle and titration-ladder tests exist specifically as safety nets for that class of bug.

## Deployment

The production stack is Synology + Portainer + Cloudflare Tunnel. Tim deploys manually via git: he pulls the desired revision on the Synology and rebuilds through Portainer. He has roughly 200 tagged versions in GitHub serving as version history, which is what makes manual git deploys workable (any prior version is a checkout away). The `docker-compose.prod.yml` carries a Watchtower-enable label but Watchtower is not actually in his deploy loop; treat the label as dormant. GitHub Actions builds images to GHCR on every push to main, mostly for record-keeping and rollback availability.

The entrypoint shell script at `scripts/entrypoint.sh` handles four DB states: empty (alembic creates from baseline), Alembic-managed at a known revision (alembic upgrades), legacy schema without `alembic_version` (stamp head then upgrade), and pinned to an unknown revision (drop legacy auth tables, clear alembic_version, stamp at new baseline, preserve feedback rows). It also defensively sweeps stale migration files and orphaned modules from layered deploys. The orphaned-files list is hardcoded; future cleanups append to it.

**Important deploy precedent (session 3).** Tim extracted a new tarball on top of an existing folder. Old auth files surfaced in the deployed image, the pricing page reappeared, his backup also showed the broken state, and he initially concluded that the bundle had destroyed his project. Root cause was layered files plus stale DB state, not the bundle. Future implication: when Tim reports a broken deploy, check the entrypoint defensive sweeps and the DB state before blaming the bundle.

## What's deferred or in flight

- Auth and billing outsourced; old schema removed. Disclaimer acceptance reserved for when auth returns.
- Ketamine standalone calculator removal pending (see above).
- Pain scoring tool deferred; Tim is not ready to add this.
- Corrected calcium flagged as inaccurate; do NOT adopt the mdcalc.com version as-is.
- APPLE-fast built but intentionally hidden; specialist-leaning, not ready for the general audience.
- Sentry wired up; may not be fully exercised.

## How to communicate with Tim

He's typically on the mobile app. Brief responses are appreciated. Lead with the answer, not the preamble. For complex tasks, prose paragraphs with minimal headers work better than long bullet lists. Avoid bullet-mania.

Don't oversell understanding. If you have not read X, say so. If you haven't verified Y, say so. Tim has paid for sessions where Claude claimed understanding and then drifted; he catches it. "I read the file but I'd want to verify before changing it" is better than confidently winging the change.

When he says "Continue" with no other context, he is asking you to resume an interrupted task. The transcript file in `/mnt/transcripts/` and the pickup file at `READTHROUGH_PICKUP.md` are your sources for what was in flight.

When he gives a directive in caps ("READ. EVERY. LINE."), it is not rhetorical.

Provide concrete artifacts (files, diffs, a bundle) when he asks for them. Avoid asking for clarification on questions you can answer from the codebase yourself.

## Past failure modes (do not repeat)

- Claiming to have read the project when only skimming. Tim has explicitly tested this multiple times.
- Em-dashes scattered through long-form prose, articles, warnings.
- Refactoring the anesthesia worksheet shape.
- Defaulting to Google services (Fonts, Analytics, Maps) instead of asking.
- Forgetting that prior conversations exist. The transcripts at `/mnt/transcripts/` are the project history.
- Defaulting to assumed conventions instead of reading `docs/style-guide.md`.
- Renaming the bundle to anything other than `cageside.tar.gz`.
- Auto-fixing em-dashes everywhere including code comments instead of just in long-form prose.
- Conflating the per-calculator clinical background section with the separate `/learn/` learning module. They are different things; clinical background lives on each calculator page, the learn module is a separate top-level area.

## Recent rolling fix history

- Blood gas + LDDST placeholder text fix. The shared placeholder partial defaulted to "Enter a patient weight to see the result." Both pages have no weight input. Fix added `placeholder_message=` override.
- Blood gas form gained species/sample-aware reference range hints via CSS `:has()` scoped with the `bg-form` class.
- Open-calculator link for 11 bespoke calculators was broken in the clinical background article. Fixed via `_resolve_calc_url(article_slug)` in `app/routers/content.py` with a `_CALC_URL_OVERRIDES` map (e.g. energy-requirements → /energy).
- Practice multiple-choice radios were not grouped per question; fixed in `app/templates/practice/_problem_card.html` with `{% set check_idx = loop.index0 %}` so radios in the same question share a `name` attribute.
- GABA_A → GABA-A normalized across 5 surfaces.

## Provenance

Written 2026-06-05 by a session-12 Claude (Sonnet 4.7) after reading every source file, every doc, every test, every template, every drug article, all configs, and all 20 prior conversation transcripts in `/mnt/transcripts/`. Cross-checked against the session-12 `READTHROUGH_PICKUP.md`.

If you find this document drifting from current practice, fix it. Don't let it stale. The whole point is to avoid forcing future sessions to repeat the read-through.
