# Deployment — InfusionFox

Production flow:

```
git push → GitHub Actions builds → GHCR registry → Watchtower pulls → container restarts
```

You never SSH in to deploy. After the one-time setup below, every push to `main`
triggers a new build, and the production container updates itself within 5 minutes.

---

## One-time setup

### 1. Create the GitHub repo

Private repo is fine — GHCR works with private repos and costs nothing for
reasonable usage. Push your InfusionFox code to it.

### 2. Verify GitHub Actions runs

The first `git push` to `main` should kick off `.github/workflows/build.yml`.
Watch it in the Actions tab. On success, you'll see a new package under
**Packages** on your GitHub profile.

The image will be at `ghcr.io/<your-username>/infusionfox:latest`.

### 3. Make the image visible to your VPS

By default, GHCR images inherit the repo's visibility (private). You have two choices:

**Option A — keep it private (recommended for proprietary code):**
Generate a Personal Access Token (classic) at
https://github.com/settings/tokens with only the `read:packages` scope, then on
your VPS run:

```bash
echo YOUR_TOKEN | docker login ghcr.io -u YOUR_USERNAME --password-stdin
```

This writes credentials to `~/.docker/config.json`, which Watchtower then
reads from (the compose file mounts it in read-only).

**Option B — make the package public:**
On the GHCR package page, change visibility to public. Then no auth is needed.
The image is still only built from your private source code; just the compiled
image becomes publicly pullable. Acceptable if you're comfortable with anyone
being able to download and inspect the image.

### 4. Edit `docker-compose.prod.yml`

Change the line:

```yaml
image: ghcr.io/YOUR-GITHUB-USERNAME/infusionfox:latest
```

to match your actual GHCR path.

### 5. Set up the Cloudflare Tunnel

In Cloudflare → Zero Trust → Networks → Tunnels → Create Tunnel. Name it
`infusionfox-prod` or similar. Cloudflare gives you a token — copy it.

Create a Public Hostname on the tunnel: `infusionfox.com` → `http://infusionfox:8000`
(the service name in the compose file). Also add `www.infusionfox.com` → same
target.

### 6. Fill in `.env` on the VPS

```bash
cp .env.example .env
# Edit .env and set:
#   CLOUDFLARE_TUNNEL_TOKEN=...  (from step 5)
#   RESEND_API_KEY=...           (once Pass 4 lands)
#   STRIPE_SECRET_KEY=...        (once Pass 4 lands)
```

### 7. Start everything

```bash
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d
```

Verify:
- `docker ps` shows infusionfox, infusionfox_tunnel, infusionfox_watchtower all running
- `curl http://localhost:8000/health` from inside the VPS returns `{"status":"ok"}` (hit the container directly through the internal network; not exposed on the host)
- `https://infusionfox.com/health` from anywhere returns the same

### 8. Promote yourself to admin (one-time)

```bash
# Temporarily add to .env on the VPS:
echo 'INFUSIONFOX_ADMIN_TOKEN=pick-a-long-random-string' >> .env
docker compose -f docker-compose.prod.yml up -d

# Register via the website normally, then:
curl -X POST -H "X-Admin-Token: pick-a-long-random-string" \
    https://infusionfox.com/admin/users/1/promote

# Then remove the token from .env and restart:
sed -i '/INFUSIONFOX_ADMIN_TOKEN/d' .env
docker compose -f docker-compose.prod.yml up -d
```

---

## Ongoing

### Deploy a new version

```bash
git push
```

That's it. GitHub Actions builds the image, pushes `:latest` to GHCR, and
Watchtower picks it up within 5 minutes. Current container is stopped, new
one is started, SQLite volume is preserved.

### Check Watchtower activity

```bash
docker logs infusionfox_watchtower --tail 50
```

Or via Dozzle.

### Roll back to a previous version

Every build also pushes a `:sha-<short>` tag. To pin to an older version,
temporarily change the image tag in `docker-compose.prod.yml`:

```yaml
image: ghcr.io/you/infusionfox:sha-abc1234
```

Then `docker compose -f docker-compose.prod.yml up -d`. Watchtower won't touch
it because it's no longer on `latest`. Fix the bug, push to main, switch back
to `:latest`.

### Backups

`infusionfox_data` is a named Docker volume containing the SQLite database and
any generated files. Back it up regularly. A minimal approach:

```bash
# Nightly cron on the VPS
docker run --rm \
    -v infusionfox_infusionfox_data:/data:ro \
    -v /backup:/backup \
    alpine \
    tar czf /backup/infusionfox-$(date +%F).tar.gz /data
```

For offsite backup, rclone the resulting tarballs to Backblaze B2 or your
NAS via Tailscale. Will formalize this in Pass 3b as a dedicated backup
service in the compose file.

### Monitoring

- **Uptime:** Uptime Kuma pointed at `https://infusionfox.com/health`, 60-second interval.
- **Logs:** Dozzle shows live container logs.
- **Metrics:** Grafana — InfusionFox itself doesn't expose Prometheus metrics yet. When it matters, I'll add `prometheus-fastapi-instrumentator` and a `/metrics` endpoint.

### If GHCR is down or rate-limits you

Fallback: SSH in, `git pull` the repo, `docker compose -f docker-compose.yml up -d --build` (the dev compose file, which builds locally). Disables the auto-update flow until GHCR is back.

---

## Why not…

- **Why not use `build: .` and Watchtower together?** Watchtower can't trigger
  a rebuild — it only pulls. `build: .` means your image is only as current as
  your last manual `docker compose up --build`. The CI pipeline makes every
  push an automatic deploy.

- **Why not Docker Hub?** GHCR is free for private images, authenticates via
  your existing GitHub permissions, and keeps source + registry in one place.
  Docker Hub's free tier has rate limits that bite servers polling regularly.

- **Why not a self-hosted registry?** One more thing to maintain. Also, you'd
  have to expose it (or VPN to it) for the VPS to pull from. GHCR removes
  this friction.

- **Why 5-minute poll interval?** Balances "responsive to deploys" with
  "doesn't hammer the registry." Lower if you want; higher if you forget
  about GHCR for months.
